package bridge;

@FunctionalInterface
public interface BridgeNumberGenerator {

    int generate();
}
